package PageFactory;

import org.testng.annotations.Test;


import PageFactory.LoginPage;

public class Login extends PreAndPost_Condition {


    @Test 
	public void login()
	{
		new LoginPage()
		.enterUsername()
		.enterpassword()
		.ClickLoginButton();
    	



	}
}
