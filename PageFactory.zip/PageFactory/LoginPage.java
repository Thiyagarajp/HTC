package PageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPage extends PreAndPost_Condition {


	public LoginPage(){
		System.out.println("page factory");

		// This is to load all the elements in the page
		PageFactory.initElements(driver, this);

	}

	@FindBy(how=How.XPATH,using="//input[@name='user_name']")
	private WebElement UserName;
    public LoginPage enterUsername()
	{
    	 /* 	WebDriverWait wait = new WebDriverWait(driver, 10);
    	wait.until(ExpectedConditions.elementToBeClickable(UserName));*/
		type(UserName, "21372");

		return this;
	}
	@FindBy(how=How.NAME,using="user_pass")
	private WebElement Password;

	public LoginPage enterpassword()
	{
		type(Password, "Welcome014");

		return this;
	}
	
	@FindBy(how=How.NAME,using="subBtn")
	private WebElement subBtn;
	public mainpage  ClickLoginButton()
	{
		click(subBtn);
		return new  mainpage();

	}
	
}
