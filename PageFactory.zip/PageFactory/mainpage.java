package PageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class mainpage extends PreAndPost_Condition {


	public mainpage()  {

		PageFactory.initElements(driver,  this);
	}

	@FindBy(how=How.CLASS_NAME,using="logoutLink")
	private WebElement LOGOUT;
	public mainpage  ClickLogout()
	{
		click(LOGOUT);
		return this;

	
	}
	
}
	

